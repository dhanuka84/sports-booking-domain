package com.sportsbook.payment.validator;

import com.sportsbook.payment.contracts.DepositEnrichedEvent;
import com.sportsbook.payment.contracts.DepositInitiatedEvent;
import com.sportsbook.payment.validator.ports.CreditCheckPort;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.context.TestPropertySource;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@SpringBootTest
@EmbeddedKafka(partitions = 1, topics = { "deposit-enriched", "deposit-enriched.DLT" })
@TestPropertySource(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "spring.datasource.url=jdbc:h2:mem:validator_dlt;DB_CLOSE_DELAY=-1",
        "spring.datasource.driverClassName=org.h2.Driver",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.show-sql=false"
})
class PaymentValidatorDltTest {

    @Autowired
    private KafkaTemplate<String, Object> genericKafkaTemplate;

    @Autowired
    private EmbeddedKafkaBroker broker;

    @MockBean
    private CreditCheckPort creditCheckPort;

    @Test
    void whenProcessingFails_messageIsRoutedToDlt() {
        var initiated = DepositInitiatedEvent.newDeposit(
                "player-dlt-1",
                new BigDecimal("50.00"),
                "SEK",
                "CARD",
                "DEBIT-DLT-1"
        );
        var enriched = DepositEnrichedEvent.noRisk(initiated);

        when(creditCheckPort.checkSource(enriched))
                .thenThrow(new RuntimeException("Bank API hard failure"));

        genericKafkaTemplate.send("deposit-enriched", initiated.playerId(), enriched);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException ignored) {}

        Map<String, Object> consumerProps = KafkaTestUtils.consumerProps(
                "test-dlt-consumer", "true", broker);
        consumerProps.put(org.apache.kafka.clients.consumer.ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                StringDeserializer.class);
        consumerProps.put(org.apache.kafka.clients.consumer.ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                JsonDeserializer.class);
        consumerProps.put(JsonDeserializer.TRUSTED_PACKAGES, "com.sportsbook.payment.contracts");

        var cf = new DefaultKafkaConsumerFactory<String, DepositEnrichedEvent>(consumerProps);
        var consumer = cf.createConsumer();
        broker.consumeFromAnEmbeddedTopic(consumer, "deposit-enriched.DLT");

        ConsumerRecords<String, DepositEnrichedEvent> records =
                consumer.poll(Duration.ofSeconds(3));

        assertThat(records.count()).isGreaterThanOrEqualTo(1);
    }
}
