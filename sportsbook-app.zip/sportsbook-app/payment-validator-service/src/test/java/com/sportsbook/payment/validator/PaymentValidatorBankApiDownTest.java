package com.sportsbook.payment.validator;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.sportsbook.payment.contracts.DepositEnrichedEvent;
import com.sportsbook.payment.contracts.DepositInitiatedEvent;
import com.sportsbook.payment.contracts.FundingSourceType;
import com.sportsbook.payment.validator.domain.DepositDecisionRepository;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.TestPropertySource;

import java.math.BigDecimal;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@EmbeddedKafka(partitions = 1, topics = { "deposit-enriched" })
@TestPropertySource(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "spring.datasource.url=jdbc:h2:mem:validator_bankdown;DB_CLOSE_DELAY=-1",
        "spring.datasource.driverClassName=org.h2.Driver",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.show-sql=false",
        "psv.nordic-api.base-url=http://localhost:18089",
        "resilience4j.circuitbreaker.instances.bankApiBreaker.slidingWindowSize=2",
        "resilience4j.circuitbreaker.instances.bankApiBreaker.minimumNumberOfCalls=2",
        "resilience4j.circuitbreaker.instances.bankApiBreaker.failureRateThreshold=50",
        "resilience4j.circuitbreaker.instances.bankApiBreaker.waitDurationInOpenState=5s"
})
class PaymentValidatorBankApiDownTest {

    @Autowired
    private KafkaTemplate<String, Object> genericKafkaTemplate;

    @Autowired
    private CircuitBreakerRegistry circuitBreakerRegistry;

    @Autowired
    private DepositDecisionRepository decisionRepository;

    private WireMockServer wireMockServer;

    @BeforeEach
    void setUp() {
        wireMockServer = new WireMockServer(18089);
        wireMockServer.start();
        configureFor("localhost", 18089);

        stubFor(post(urlEqualTo("/funding-source/check"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withBody("bank down")));
    }

    @AfterEach
    void tearDown() {
        if (wireMockServer != null) {
            wireMockServer.stop();
        }
    }

    @Test
    void repeatedBankFailures_shouldOpenCircuitBreaker_andNoDecisionsPersisted() {
        var cb = circuitBreakerRegistry.circuitBreaker("bankApiBreaker");

        for (int i = 0; i < 2; i++) {
            var initiated = DepositInitiatedEvent.newDeposit(
                    "player-bankdown-" + i,
                    new BigDecimal("10.00"),
                    "SEK",
                    "CARD",
                    "DEBIT-BANKDOWN-" + i
            );
            var enriched = DepositEnrichedEvent.noRisk(initiated);

            genericKafkaTemplate.send("deposit-enriched", initiated.playerId(), enriched);
        }

        try {
            Thread.sleep(4000);
        } catch (InterruptedException ignored) {}

        assertThat(cb.getState()).isEqualTo(CircuitBreaker.State.OPEN);
        assertThat(decisionRepository.count()).isEqualTo(0);
    }
}
