package com.sportsbook.bettingservice.outbox;

public interface OutboxSendPort {
    void send(String topic, String key, byte[] avroBinary);
}