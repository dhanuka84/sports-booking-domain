package com.sportsbook.bettingservice.api.dto;

public record PlaceBetResponse(String betId) {
}