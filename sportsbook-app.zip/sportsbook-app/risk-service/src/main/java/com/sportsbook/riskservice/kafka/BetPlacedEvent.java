package com.sportsbook.riskservice.kafka;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class BetPlacedEvent {
    private String betId;
    private String playerId;
    private String userId;
    private String matchId;
    private String selection;
    private double stake;
    private double odds;


}